from django.db import models
import json

class Level(models.Model):
    number = models.IntegerField(unique=True)  # 关卡编号
    map_data = models.TextField()  # 存储地图数据（JSON）
    box_positions = models.TextField()  # 存储箱子位置（JSON）
    person_position = models.TextField()  # 存储人物位置（JSON）

    def __str__(self):
        return f"Level {self.number}"

    def get_map(self):
        return json.loads(self.map_data)

    def get_box_positions(self):
        return json.loads(self.box_positions)

    def get_person_position(self):
        return json.loads(self.person_position)

from django.db import models

class level_records(models.Model):
    user_id = models.CharField(max_length=100)
    level = models.IntegerField()
    steps = models.IntegerField()
    score = models.IntegerField()
