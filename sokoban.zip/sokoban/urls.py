from django.urls import path
from . import views



urlpatterns = [

    path('', views.get_levels, name='get_levels'),
    path('admin/', views.admin, name='admin'),

    path("admin/delete_level/<int:level_number>/", views.delete_level, name="delete_level"),
]
