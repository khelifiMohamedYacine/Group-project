from django.contrib import admin
from .models import Level
from .models import level_records


@admin.register(Level)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('number', 'map_data', 'box_positions', 'person_position')  # 在后台列表
@admin.register(level_records)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('user_id', 'level', 'steps')  # 在后台列表中显示的字段
