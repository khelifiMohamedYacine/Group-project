import json
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt

from sokoban import models
from sokoban.models import Level
from sokoban.models import level_records

@csrf_exempt
def get_levels(request):
    if request.method == "POST":
        user_id = request.POST.get('user_id')
        level = request.POST.get('level')
        steps = request.POST.get('steps')
        score = request.POST.get('score')
        models.level_records.objects.create(user_id=user_id, level=level, steps=steps, score=score)

    levels = Level.objects.all().values("number", "map_data", "box_positions", "person_position")

    levels_list = []
    for level in levels:
        levels_list.append({
            "number": level["number"],
            "map_data": json.loads(level["map_data"]),
            "box_positions": json.loads(level["box_positions"]),
            "person_position": json.loads(level["person_position"])
        })

    return render(request, 'sokoban/SokobanGame-version1.html', {"levels": json.dumps(levels_list)})

import json
from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from sokoban.models import Level

@csrf_exempt
def admin(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            for level_data in data:
                level, created = Level.objects.update_or_create(
                    number=level_data["number"],
                    defaults={
                        "map_data": json.dumps(level_data["map_data"]),
                        "box_positions": json.dumps(level_data["box_positions"]),
                        "person_position": json.dumps(level_data["person_position"])
                    }
                )

            return JsonResponse({"message": "Levels updated successfully!", "success": True})
        except json.JSONDecodeError:
            return JsonResponse({"error": "Invalid JSON"}, status=400)

    levels = Level.objects.all().values("number", "map_data", "box_positions", "person_position")
    levels_list = []
    for level in levels:
        levels_list.append({
            "number": level["number"],
            "map_data": json.loads(level["map_data"]),
            "box_positions": json.loads(level["box_positions"]),
            "person_position": json.loads(level["person_position"])
        })

    return render(request, 'sokoban/admin.html', {"levels": json.dumps(levels_list)})


@csrf_exempt
def delete_level(request, level_number):
    if request.method == "DELETE":
        try:
            level = Level.objects.get(number=level_number)
            level.delete()
            return JsonResponse({"success": True, "message": f"Level {level_number} deleted successfully!"})
        except Level.DoesNotExist:
            return JsonResponse({"success": False, "error": "Level not found."})
    return JsonResponse({"success": False, "error": "Invalid request method."}, status=400)
