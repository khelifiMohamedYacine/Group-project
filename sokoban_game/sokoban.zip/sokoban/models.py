from django.db import models
import json

class Level(models.Model):
    number = models.IntegerField(unique=True)
    map_data = models.TextField()
    box_positions = models.TextField()
    person_position = models.TextField()

    def __str__(self):
        return f"Level {self.number}"

    def get_map(self):
        return json.loads(self.map_data)

    def get_box_positions(self):
        return json.loads(self.box_positions)

    def get_person_position(self):
        return json.loads(self.person_position)

from django.db import models

class level_records(models.Model):
    user_id = models.CharField(max_length=100)
    level = models.IntegerField()
    steps = models.IntegerField()
    score = models.IntegerField()
